/*
 * JBossWS WS-Tools Generated Source
 *
 * Generation Date: Sun Feb 07 20:49:56 CET 2010
 *
 * This generated source code represents a derivative work of the input to
 * the generator that produced it. Consult the input for the copyright and
 * terms of use that apply to this source code.
 */

package org.jboss.test.ws.jaxrpc.samples.jsr109pojo;


public class  JaxRpcTestService_echoSimpleUserType_ResponseStruct
{

protected org.jboss.test.ws.jaxrpc.samples.jsr109pojo.SimpleUserType result;
public JaxRpcTestService_echoSimpleUserType_ResponseStruct(){}

public JaxRpcTestService_echoSimpleUserType_ResponseStruct(org.jboss.test.ws.jaxrpc.samples.jsr109pojo.SimpleUserType result){
this.result=result;
}
public org.jboss.test.ws.jaxrpc.samples.jsr109pojo.SimpleUserType getResult() { return result ;}

public void setResult(org.jboss.test.ws.jaxrpc.samples.jsr109pojo.SimpleUserType result){ this.result=result; }

}
