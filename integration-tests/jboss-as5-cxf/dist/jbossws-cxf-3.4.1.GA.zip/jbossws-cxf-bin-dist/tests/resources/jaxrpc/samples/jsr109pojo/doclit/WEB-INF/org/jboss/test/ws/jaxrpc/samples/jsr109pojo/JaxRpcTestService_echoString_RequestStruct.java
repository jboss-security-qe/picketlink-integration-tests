/*
 * JBossWS WS-Tools Generated Source
 *
 * Generation Date: Sun Feb 07 20:49:56 CET 2010
 *
 * This generated source code represents a derivative work of the input to
 * the generator that produced it. Consult the input for the copyright and
 * terms of use that apply to this source code.
 */

package org.jboss.test.ws.jaxrpc.samples.jsr109pojo;


public class  JaxRpcTestService_echoString_RequestStruct
{

protected java.lang.String string_1;

protected java.lang.String string_2;
public JaxRpcTestService_echoString_RequestStruct(){}

public JaxRpcTestService_echoString_RequestStruct(java.lang.String string_1, java.lang.String string_2){
this.string_1=string_1;
this.string_2=string_2;
}
public java.lang.String getString_1() { return string_1 ;}

public void setString_1(java.lang.String string_1){ this.string_1=string_1; }

public java.lang.String getString_2() { return string_2 ;}

public void setString_2(java.lang.String string_2){ this.string_2=string_2; }

}
