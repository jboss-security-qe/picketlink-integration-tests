/*
 * JBossWS WS-Tools Generated Source
 *
 * Generation Date: Sun Feb 07 20:49:54 CET 2010
 *
 * This generated source code represents a derivative work of the input to
 * the generator that produced it. Consult the input for the copyright and
 * terms of use that apply to this source code.
 */

package org.jboss.test.ws.jaxrpc.samples.docstyle.wrapped;


public class  TrivialService_purchase_ResponseStruct
{

protected java.lang.String result;
public TrivialService_purchase_ResponseStruct(){}

public TrivialService_purchase_ResponseStruct(java.lang.String result){
this.result=result;
}
public java.lang.String getResult() { return result ;}

public void setResult(java.lang.String result){ this.result=result; }

}
